<?php

namespace App\Providers;

use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Force URL generator to use APP_URL so asset(), url(), and @vite work in subdirectory
        URL::forceRootUrl(config('app.url'));

        // Share branding (logo, colors) with all views
        View::composer('*', function ($view) {
            $view->with([
                'brandingLogoUrl' => \App\Helpers\BrandingHelper::logoUrl(),
                'brandingLogoDarkUrl' => \App\Helpers\BrandingHelper::logoDarkUrl(),
                'brandingLogoIconUrl' => \App\Helpers\BrandingHelper::logoIconUrl(),
                'brandingAuthLogoUrl' => \App\Helpers\BrandingHelper::authLogoUrl(),
                'brandingColorCss' => \App\Helpers\BrandingHelper::brandColorCss(),
            ]);
        });
    }
}
